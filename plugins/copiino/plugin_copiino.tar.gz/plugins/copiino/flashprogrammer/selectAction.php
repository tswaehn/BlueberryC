
<?php

  
?>

<h3>FlashProgrammer</h3>

</ul>
<div id="controls_item">
<a href="<?php postToMe('read'); ?>">read</a> 
<br>
the current program from chip
</div>

<div id="controls_item">
<a href="<?php postToMe('filesStorage'); ?>">write</a> 
<br>
a hex file to the chip
</div>

<div id="controls_item">
<a href="<?php postToMe('filesStorage'); ?>">Files Storage</a> 
<br>
view current available files
</div>

