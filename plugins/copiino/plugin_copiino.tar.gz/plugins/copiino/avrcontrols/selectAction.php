
<?php

  
?>

<h3>AVR Tools</h3>


<div id="controls_item">
<a href="<?php postToMe('start_avr'); ?>">start AVR</a> 
<br>
starts the onboard AVR
</div>

<div id="controls_item">
<a href="<?php postToMe('stop_avr'); ?>">stop AVR</a> 
<br>
stops the onboard AVR
</div>

