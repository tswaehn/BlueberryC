
<?php

  setCaption( "RS232 Terminal" );

  setDefaultPage( PLUGIN_DIR.'index.php' );

    
?>



 
 
 
